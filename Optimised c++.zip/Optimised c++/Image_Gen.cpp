#include <iostream>
#include <fstream>
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h" //Drawing images
#include <vector>
#include <string>
using namespace std;

/*
cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++

g++ -Ofast -march=native -flto -std=c++20 -o Image_Gen Image_Gen.cpp
*/

/*int main(){

    int size = 10000;
    char horizontal;
    char vertical;
    int x = 1;
    int y = 1;
    vector<unsigned char> image((size*2+1)*(size*2+1)*3, 0);

    fstream mazeTXT;
    mazeTXT.open("Maze.txt", ios::in);

    for (int a = 0; a < size; a++) { //Horizontal
        for (int b = 0; b < size-1; b++) {
            image[(y*(size*2+1)+x)*3 + 0] = 255;
            image[(y*(size*2+1)+x)*3 + 1] = 255;
            image[(y*(size*2+1)+x)*3 + 2] = 255; //y*(size*2+1)+x
            x += 1;
            if (mazeTXT >> horizontal; horizontal == '0') {
                image[(y*(size*2+1)+x)*3 + 0] = 255;
                image[(y*(size*2+1)+x)*3 + 1] = 255;
                image[(y*(size*2+1)+x)*3 + 2] = 255; 
            }
            x += 1;
        }
        image[(y*(size*2+1)+x)*3 + 0] = 255;
        image[(y*(size*2+1)+x)*3 + 1] = 255;
        image[(y*(size*2+1)+x)*3 + 2] = 255; 
        y += 2;
        x = 1;
    }

    y = 2;
    x = 1;

    for (int a = 0; a < size-1; a++) { //Vertical
        for (int b = 0; b < size; b++) {
            if (mazeTXT >> vertical; vertical == '0') {
                image[(y*(size*2+1)+x)*3 + 0] = 255;
                image[(y*(size*2+1)+x)*3 + 1] = 255;
                image[(y*(size*2+1)+x)*3 + 2] = 255; 
            }
            x += 2;
        }
        y += 2;
        x = 1;
    }
    mazeTXT.close();
    //Automatic image output (for small mazes <= 10,000)
    stbi_write_png("maze.png", size*2+1, size*2+1, 3, image.data(), (size*2+1)*3); //This is the problem - too much data
    //Manual ppm p5 image output (for large mazes ~> 10,000)
    fstream mazeimage;
    mazeimage.open("MazeImage.ppm", ios::out);
    mazeimage << "p4\n" << size*2+1 << " " << size*2+1 << "\n1\n";
    mazeimage.write(reinterpret_cast<const char*>(image.data()), image.size());
    mazeimage.close();
    return 0;
}*/
int main(){
    int size = 1000;
    char horizontal;
    char vertical;
    int x = 1;
    int y = 1;
    vector<unsigned char> image((size*2+1)*(size*2+1), 0);

    fstream mazeTXT;
    mazeTXT.open("Maze.txt", ios::in);

    for (int a = 0; a < size; a++) { //Horizontal
        for (int b = 0; b < size-1; b++) {
            image[(y*(size*2+1)+x)] = 255;
            x += 1;
            if (mazeTXT >> horizontal; horizontal == '0') {
                image[(y*(size*2+1)+x)] = 255;
            }
            x += 1;
        }
        image[(y*(size*2+1)+x)] = 255;
        y += 2;
        x = 1;
    }

    y = 2;
    x = 1;

    for (int a = 0; a < size-1; a++) { //Vertical
        for (int b = 0; b < size; b++) {
            if (mazeTXT >> vertical; vertical == '0') {
                image[(y*(size*2+1)+x)] = 255;
            }
            x += 2;
        }
        y += 2;
        x = 1;
    }
    mazeTXT.close();
    //Automatic image output (for small mazes <= 20,000)
    stbi_write_png("maze.png", size*2+1, size*2+1, 1, image.data(), (size*2+1)); //This is the problem - too much data
    //Manual ppm p5 image output (for large mazes ~> 20,000)
    //fstream mazeimage;
    //mazeimage.open("MazeImage.ppm", ios::out);
    //mazeimage << "p4\n" << size*2+1 << " " << size*2+1 << "\n1\n";
    //mazeimage.write(reinterpret_cast<const char*>(image.data()), image.size());
    //mazeimage.close();
    return 0;
}