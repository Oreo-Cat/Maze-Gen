#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <random>

//using namespace std;std::

/*
cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++

g++ -Ofast -march=native -flto -std=c++20 -o -I"C:/Program Files/ImageMagick-7.1.2-Q16/include" -L"C:/Program Files/ImageMagick-7.1.2-Q16/lib" -lMagick++-7.Q16HDRI Maze_program_Optimised Maze_Optimised_300000.cpp
*/
std::vector<uint8_t> bit_pack(std::vector<bool> data) { //Bit packing image data.
    int bits = 0;
    uint8_t byte = 0;
    std::vector<uint8_t> row;
    row.reserve((data.size()+7)/8);
    for (int i = 0; i < data.size(); i++) {
        byte <<= 1;
        if (data[i]) {
            byte |= 1;
        }
        bits++;
        if (bits == 8) {
            row.push_back(byte);
            byte = 0;
            bits = 0;
        }
    }
    std::cout << bits << static_cast<int>(byte);
    if (bits) {
        byte <<= (8-bits);
        row.push_back(byte);
    }
    std::cout << static_cast<int>(row.back());
    return row;
}

int main() {
    int size = 1000;
    int completed = 0;
    int choices[4] = { 0, 0, 0, 0 };
    int chosen = 0;
    int wall = 0;
    int choicelength = 0;
    std::vector<bool> horizontal_vec(size * (size - 1), true);
    std::vector<bool> vertical_vec(size * (size - 1), true);
    std::vector<int> VNC;
    VNC.reserve(size * size / 3); //This might be why higher loop numbers results in slower code - (size*size) instead maybe
    std::vector<int> VNC_map(size * size, -1);
    std::vector<bool> visited(size * size, false);
    int percent = 0;

    srand(time(NULL));
    std::random_device random_device;
    std::minstd_rand random_engine{random_device()};
    std::uniform_int_distribution dist_init{0, size * size - 1};
    std::uniform_int_distribution dist_choice{0, 3};

    int current = dist_init(random_engine); //Using <random> instead because cstdint rand() has a limit for large numbers.
    std::cout << current << "\n";
    visited[current] = true;
    VNC.push_back(current);
    VNC_map[current] = VNC.size() - 1;


    while (completed < size * size) {
        int loop = 1; //(rand() % 1) + 1; //Need to investigate - at higher loop numbers, code runs slower.        1, 1;    3, 3;    3, 8;    3, 28;
        for (int i = 0; i < loop; i++) {
            if (completed >= size * size) { break; }
            percent++;
            if (percent % (size * size / 100) == 0) {
                std::cout << int(completed / float(size * size) * 100) << " Percent completed" << "\n";
            }

            choicelength = 0;
            //Left
            if (current - 1 >= 0 && visited[current - 1] == false && current % size != 0) {
                choices[choicelength] = current - 1;
                choicelength += 1;
            }
            //Right
            if (current + 1 <= size * size && visited[current + 1] == false && (current + 1) % size != 0) {
                choices[choicelength] = current + 1;
                choicelength += 1;
            }
            //Above
            if (current - size >= 0 && visited[current - size] == false && current - size < size * size && (current - size) > 0) {
                choices[choicelength] = current - size;
                choicelength += 1;
            }
            //Below
            if (current + size <= size * size && visited[current + size] == false && current + size < size * size && (current + size) > 0) {
                choices[choicelength] = current + size;
                choicelength += 1;
            }
            if (choicelength <= 1) { //Because if there is one path it will be taken later anyway.
                completed++;
                if (VNC_map[current] != -1) {
                    std::swap(VNC[VNC_map[current]], VNC.back());
                    std::swap(VNC_map[current], VNC_map[VNC[VNC_map[current]]]);
                    VNC.pop_back();
                    VNC_map[current] = -1;
                }
                if (choicelength == 0) { break; } // No choices available, exit the loop.
            }
            chosen = choices[rand() % choicelength]; //Randomly choose one of the choices.
            VNC.push_back(chosen);
            VNC_map[chosen] = VNC.size() - 1;
            visited[chosen] = true;
            //Left
            if (current - chosen == 1) {
                wall = chosen / size * (size - 1) + chosen % size;
                horizontal_vec[wall] = false;
            }
            //Right
            else if (chosen - current == 1) {
                wall = current / size * (size - 1) + current % size;
                horizontal_vec[wall] = false;
            }
            //Above 
            else if (current - chosen == size) {
                vertical_vec[chosen] = false;
            }
            //Below
            else {
                vertical_vec[current] = false;
            }
            current = chosen;
        }
        if (VNC.size() != 0) {
            //int index = rand() % VNC.size(); //In python, this would be VNC.size()-1 but C++ does not include the max for rand.
            //current = VNC[index]; //RANDOM mode
            //current = VNC[0]; //FIRST mode
            current = VNC.back(); //LAST mode
        }
    }
    //.txt data saving.
    std::string htext = "";
    for (int h = 0; h < horizontal_vec.size(); h++) {
        if (horizontal_vec[h] == true) { htext.append("1"); }
        else { htext.append("0"); }
    }
    std::string vtext = "";
    for (int v = 0; v < vertical_vec.size(); v++) {
        if (vertical_vec[v] == true) { vtext.append("1"); }
        else { vtext.append("0"); }
    }
    std::fstream MazeTXT;
    MazeTXT.open("Maze.txt", std::ios::out);
    MazeTXT << htext;
    MazeTXT << vtext;
    MazeTXT.close();

    //Image saving
    std::cout << "Program will close when image is generated.\n";
    int horizontal = 0;
    int vertical = 0;
    int x = 1;
    int y = 1;

    std::fstream mazeimage;
    mazeimage.open("MazeImage.ppm", std::ios::out);
    mazeimage << "P4\n" << size*2+1 << " " << size*2+1 << "\n";
    std::vector<bool> image((size * 2 + 1), 0);
    mazeimage.write(reinterpret_cast<const char*>(bit_pack(image).data()), bit_pack(image).size());///////
    //std::fill(image.begin(), image.end(), 0);

    for (int a = 0; a < size - 1; a++) { //Horizontal
        for (int b = 0; b < size - 1; b++) {
            image[x] = 1;
            x += 1;
            if (horizontal_vec[horizontal] == false) {
                image[x] = 1;
            }
            horizontal++;
            x += 1;
        }
        image[x] = 1;
        mazeimage.write(reinterpret_cast<const char*>(bit_pack(image).data()), bit_pack(image).size());///////
        std::fill(image.begin(), image.end(), 0);
        x = 1;
        for (int b = 0; b < size; b++) { //Vertical
            if (vertical_vec[vertical] == false) {
                image[x] = 1;
            }
            vertical++;
            x += 2;
        }
        mazeimage.write(reinterpret_cast<const char*>(bit_pack(image).data()), bit_pack(image).size());///////mazeimage.write(reinterpret_cast<const char*>(image.data()), image.size());
        std::fill(image.begin(), image.end(), 0);
        x = 1;
    }
    for (int b = 0; b < size - 1; b++) {
            image[x] = 1;
            x += 1;
            if (horizontal_vec[horizontal] == false) {
                image[x] = 1;
            }
            horizontal++;
            x += 1;
        }
        image[x] = 1;
    mazeimage.write(reinterpret_cast<const char*>(bit_pack(image).data()), bit_pack(image).size());///////mazeimage.write(reinterpret_cast<const char*>(image.data()), image.size());

    std::fill(image.begin(), image.end(), 0);
    mazeimage.write(reinterpret_cast<const char*>(bit_pack(image).data()), bit_pack(image).size());///////

    mazeimage.close();
    return 0;
}