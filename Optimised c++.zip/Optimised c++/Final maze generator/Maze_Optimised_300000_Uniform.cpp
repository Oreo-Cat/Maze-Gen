#include <iostream>
#include <fstream>
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <random>
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h" //Drawing images

/*
cd C:\Users\User\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\Final maze generator
g++ -Ofast -march=native -flto -std=c++20 -o Maze_program_300000 Maze_Optimised_300000_Uniform.cpp

"C:\Users\User\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\vips-dev-8.17\bin\vips.exe" arrayjoin "All_Mazes" Full_Maze.png --across 10

cd C:\Users\User\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\Final maze generator\tiles
"C:\Users\User\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\vips-dev-8.17\bin\vips.exe" arrayjoin "Maze_0_0000.png Maze_1_0000.png Maze_2_0000.png" Full_Maze.png --across 10
*/

std::string maze_chunk_name (int chunk_pos, int chunks_amount, int sections, int num) {
    int chunk_x = chunk_pos % chunks_amount;
    int chunk_y = chunk_pos / chunks_amount * sections + num;
    std::string name = "Maze_";
    name += std::to_string(chunk_x);
    name += "_";
    for (int i = 0; i < 4 - std::to_string(chunk_y).length(); i ++) { //padding with 0s
        name += "0";
    }
    name += std::to_string(chunk_y);
    //name += std::to_string(chunk_pos*sections+num*chunks_amount+1); //For non x, y based numbering
    name += ".png";
    return name;
}

void maze(int size, int max_image_length, int left_wall, int right_wall, int above_wall, int below_wall, int current_chunk, int chunks_amount) {
    int hsize;
    int vsize;
    if (above_wall == 1 || below_wall == 1 ) { vsize = size; } else { vsize = size + 1;} //max_image_length ++ to prevent images being cropped accidently
    if (left_wall == 1 || right_wall == 1 ) { hsize = size; } else { hsize = size + 1; }

    int completed = 0;
    int choices[4] = { 0, 0, 0, 0 };
    int chosen = 0;
    int wall = 0;
    int choice_length = 0;
    std::vector<bool> horizontal_vec(vsize * (hsize - 1), true);
    std::vector<bool> vertical_vec(hsize * (vsize - 1), true);
    std::vector<unsigned int> VNC;
    VNC.reserve(hsize * vsize / 3); //This might be why higher loop numbers results in slower code - (size*size) instead maybe
    std::vector<int> VNC_map(hsize * vsize, -1); ////Maybe shouldn't be unsigned and set to a signed int
    std::vector<bool> visited(hsize * vsize, false);
    int percent = 0;

    static std::vector<bool> wall_data(size * 4 * chunks_amount * chunks_amount, true); //Alot of wasted space - wall on the edge of the full maze will never be filled and duplicate walls between chunks. System may be replaced. Should be size - 1 but is size because hsize or vsize can be 1 bigger

/*
chunk * (size * 4) + (wall * size) + i

Chunk is the chunk you want
wall is the wall you want - left 0, right 1, above 2, below 3
right 0, left 1, below 2, above 3 - wall reading
left 0, right 1, above 2, below 3 - wall writing
why? Because it doesn't need the left side of the chunk to the left of it, it needs the right side
*/
    std::random_device random_device;
    std::minstd_rand random_engine{random_device()};
    std::uniform_int_distribution dist_init{0, hsize * vsize - 1};

    unsigned int start_choices_len = 0; //The amount of cells at the front of the visited vector that are starting cells
    std::vector<bool> start_choices_map(hsize * vsize, false); //For checking if a starting cell has been chosen indirectly
    int current;

    if (left_wall < 2 && right_wall < 2 && above_wall < 2 && below_wall < 2) { //Must be the first maze chunk.
        current = dist_init(random_engine); //Using <random> instead because cstdint rand() has a limit for large numbers.
        visited[current] = true;
        VNC.push_back(current);
        VNC_map[current] = VNC.size() - 1;
    } else {
        if (left_wall == 2) { //Left wall logic
            for (int cell = 0; cell < vsize; cell ++) {
                if (visited[hsize * cell] == false) { //To prevent duplicating cells at the corners
                    visited[hsize * cell] = true;
                    VNC.push_back(hsize * cell);
                    VNC_map[hsize * cell] = VNC.size() - 1;

                    start_choices_len ++;
                    start_choices_map[hsize * cell] = true;
                }
            }
            for (int wall = 0; wall < vsize - 1; wall ++) {
                vertical_vec[wall * hsize] = wall_data[(current_chunk - 1) * size * 4 + size + wall];
            }
        }
        if (right_wall == 2) { //right wall logic
            for (int cell = 0; cell < vsize; cell ++) {
                if (visited[hsize - 1 + hsize * cell] == false) {
                    visited[hsize - 1 + hsize * cell] = true;
                    VNC.push_back(hsize - 1 + hsize * cell);
                    VNC_map[hsize - 1 + hsize * cell] = VNC.size() - 1;

                    start_choices_len ++;
                    start_choices_map[hsize - 1 + hsize * cell] = true;
                }
            }
            for (int wall = 0; wall < vsize - 1; wall ++) {
                vertical_vec[wall * hsize + hsize - 1] = wall_data[(current_chunk + 1) * size * 4 + wall];
            }
        }
        if (above_wall == 2) { //above wall logic
            for (int cell = 0; cell < hsize; cell ++) {
                if (visited[cell] == false) {
                    visited[cell] = true;
                    VNC.push_back(cell);
                    VNC_map[cell] = VNC.size() - 1;

                    start_choices_len ++;
                    start_choices_map[cell] = true;
                }
            }
            for (int wall = 0; wall < hsize - 1; wall ++) {
                horizontal_vec[wall] = wall_data[(current_chunk - chunks_amount) * size * 4 + 3 * size + wall];
            }
        }
        if (below_wall == 2) { //below wall logic
            for (int cell = 0; cell < hsize; cell ++) {
                if (visited[hsize * (vsize - 1) + cell] == false) {
                    visited[hsize * (vsize - 1) + cell] = true;
                    VNC.push_back(hsize * (vsize - 1) + cell);
                    VNC_map[hsize * (vsize - 1) + cell] = VNC.size() - 1;

                    start_choices_len ++;
                    start_choices_map[hsize * (vsize - 1) + cell] = true;
                }
            }
            for (int wall = 0; wall < size - 1; wall ++) {
                horizontal_vec[(hsize - 1) * (vsize - 1) + wall] = wall_data[(current_chunk + chunks_amount) * size * 4 + 2 * size + wall];
            }
        }
        //Current choosing logic
        current = VNC[rand() % VNC.size()];
    }

    while (completed < hsize * vsize) {
        percent++;
        if (percent % (hsize * vsize / 100) == 0) {
            //std::cout << int(completed / float(hsize * vsize) * 100) << " Percent completed" << "\n";
        }

        choice_length = 0;
        //Left
        if (current - 1 >= 0 && visited[current - 1] == false && current % hsize != 0) {
            choices[choice_length] = current - 1;
            choice_length ++;
        }
        //Right
        if (current + 1 <= hsize * vsize && visited[current + 1] == false && (current + 1) % hsize != 0) {
            choices[choice_length] = current + 1;
            choice_length ++;
        }
        //Above
        if (current - hsize >= 0 && visited[current - hsize] == false) {
            choices[choice_length] = current - hsize;
            choice_length ++;
        }
        //Below
        if (current + hsize < hsize * vsize && visited[current + hsize] == false) {
            choices[choice_length] = current + hsize;
            choice_length ++;
        }
        if (choice_length <= 1) { //Because if there is one path it will be taken later anyway.
            completed++;
            if (VNC_map[current] != -1) {
                std::swap(VNC[VNC_map[current]], VNC.back());
                std::swap(VNC_map[current], VNC_map[VNC[VNC_map[current]]]);
                VNC.pop_back();
                VNC_map[current] = -1;
            }
            if (start_choices_map[current] == true) { //A starting choice has been chosen indirectly
                start_choices_map[current] == false;
                start_choices_len --;
            }
            if (choice_length == 0) { goto skip; } // No choices available, exit the loop.
        }
        chosen = choices[rand() % choice_length]; //Randomly choose one of the choices.
        VNC.push_back(chosen);
        VNC_map[chosen] = VNC.size() - 1;
        visited[chosen] = true;
        //Left
        if (current - chosen == 1) {
            wall = chosen / hsize * (hsize - 1) + chosen % hsize;
            horizontal_vec[wall] = false;
        }
        //Right
        else if (chosen - current == 1) {
            wall = current / hsize * (hsize - 1) + current % hsize;
            horizontal_vec[wall] = false;
        }
        //Above 
        else if (current - chosen == hsize) {
            vertical_vec[chosen] = false;
        }
        //Below
        else {
            vertical_vec[current] = false;
        }
        current = chosen;
        skip:
        if (VNC.size() != 0) {
            if (start_choices_len > 0 && rand() % 10 == 1) {
                //if (rand() % 2 == 1) { //To try to make rand() less biased and stop it from prioritising the left and right wall connections
                    //current = VNC[start_choices_len - rand() % start_choices_len];
                //} else {
                    current = VNC[rand() % start_choices_len];
                //}
            } else {
                current = VNC.back();
            }

            //current = VNC[rand() % VNC.size()]; //RANDOM mode
            //current = VNC[0]; //FIRST mode
            //current = VNC.back(); //LAST mode
        }
    }

    //Wall data saving
    std::cout << "Program is saving wall data.\n";
    if (left_wall == 0) {
        for (int wall = 0; wall < vsize - 1; wall ++) {
            wall_data[current_chunk * size * 4 + wall] = vertical_vec[wall * hsize];
        }
    }
    if (right_wall == 0) {
        for (int wall = 0; wall < vsize - 1; wall ++) {
            wall_data[current_chunk * size * 4 + size + wall] = vertical_vec[wall * hsize + hsize - 1];
        }
    }
    if (above_wall == 0) {
        for (int wall = 0; wall < hsize - 1; wall ++) {
            wall_data[current_chunk * size * 4 + 2 * size + wall] = horizontal_vec[wall];
        }
    }
    if (below_wall == 0) {
        for (int wall = 0; wall < hsize - 1; wall ++) {
            wall_data[current_chunk * size * 4 + 3 * size + wall] = horizontal_vec[(hsize - 1) * (vsize - 1) + wall];
        }
    }

    //Image saving
    std::cout << "Program is generating images.\n";
    int horizontal = 0;
    int vertical = 0;
    int picture_num = 0;

    //if (max_image_length > size) {max_image_length = size;} //Clamp max_image_length - not neccesary

    int width = hsize * 2 + 1;
    if (left_wall != 1) {width -= 1;} //Black border
    if (right_wall != 1) {width -= 2;} //Black border and not removing right side

    int og_x = 0; //Original x for resetting x
    int og_y = 0; //Original y for resetting y
    if (left_wall == 1) {og_x = 2; width ++;} //Add double black border to the left. width ++ make image wider for extra pixel of border on left
    if (above_wall == 1) {og_y = 2;} //Add double black border above.
    int x = og_x;
    int y = og_y;
    int image_length = og_y;

    std::vector<uint8_t> image(width * (max_image_length * 2 + 1), 0);

    for (int a = 0; a < vsize - 1; a++) {
        for (int b = 0; b < hsize - 1; b++) { //Horizontal
            image[y*width+x] = 255; //Cell intersections
            x ++;
            if (horizontal_vec[horizontal] == false) {
                image[y*width+x] = 255; //Horizontal walls
            }
            horizontal++;
            x ++;
        }
        if (right_wall == 1) {image[y*width+x] = 255;} //Last cell intersection
        y ++;
        image_length ++;

        if (image_length == max_image_length * 2) {
            stbi_write_png(maze_chunk_name(current_chunk, chunks_amount, (size + max_image_length - 1) / max_image_length, picture_num).c_str(), width, image_length, 1, image.data(), width); //not width, height because otherwise the bottom cutoff will be taken out of all sections of image output 
            image_length = 0;
            picture_num ++;
            std::fill(image.begin(), image.end(), 0);
            y = 0; //always set to 0 here - No black borders between chunks
            std::cout << "Image section " << picture_num << " generated\n";
        }

        x = og_x;
        for (int b = 0; b < hsize; b++) { //Vertical
            if (vertical_vec[vertical] == false) {
                if (b < hsize - 1 || right_wall == 1) {image[y*width+x] = 255;} //Removing right most vertical connections when supposed to
            }
            vertical++;
            x += 2;
        }
        x = og_x;
        y ++;
        image_length ++;
        if (image_length == max_image_length * 2) {
            stbi_write_png(maze_chunk_name(current_chunk, chunks_amount, (size + max_image_length - 1) / max_image_length, picture_num).c_str(), width, image_length, 1, image.data(), width); //not width, height because otherwise the bottom cutoff will be taken out of all sections of image output 
            image_length = 0;
            picture_num ++;
            std::fill(image.begin(), image.end(), 0);
            y = 0; //always set to 0 here - No black borders between chunks
            std::cout << "Image section " << picture_num << " generated\n";
        }
    }

    if (below_wall == 1) {
        for (int b = 0; b < hsize - 1; b++) { //Last non-white horizontal row
            image[y*width+x] = 255; //Cell intersections
            x ++;
            if (horizontal_vec[horizontal] == false) {
                image[y*width+x] = 255; //Horizontal walls
            }
            horizontal++;
            x ++;
        }
        if (right_wall == 1) {image[y*width+x] = 255;} //Last cell intersection
        image_length += 2; //For black border and no cropping
    }

    if (image_length > 0) {
        stbi_write_png(maze_chunk_name(current_chunk, chunks_amount, (size + max_image_length - 1) / max_image_length, picture_num).c_str(), width, image_length, 1, image.data(), width); //(image_length * 2 + 1) + (height - (max_image_length * 2 + 1))
        picture_num ++;
        std::cout << "Image section " << picture_num << " generated\n";
    }

    std::cout << "All " << picture_num << " image sections generated\n";
}

int main() {
    int chunk_size = 30; //30,000 //In cells
    int image_output_length = 15; //15,000 //In cells
    int chunks_amount = 4; //10
    std::cout << "chunk_size\n";
    std::cin >> chunk_size;
    std::cout << "image_output_length\n";
    std::cin >> image_output_length;
    std::cout << "chunks_amount\n";
    std::cin >> chunks_amount;
    std::vector<bool> completed_chunks(chunks_amount * chunks_amount, false);
    std::vector<unsigned int> chunk_choices; //A list of all frontier chunks to generate next
    chunk_choices.reserve(chunks_amount * chunks_amount / 3);
    std::vector<bool> chunk_frontier(chunks_amount * chunks_amount, false); //Which chunks are frontier - for making sure frontier chunks aren't stored twice

    srand(time(NULL));
    std::random_device random_device;
    std::minstd_rand random_engine{random_device()};
    std::uniform_int_distribution dist_chunk{0, chunks_amount * chunks_amount - 1};
    int current_chunk = dist_chunk(random_engine);
    chunk_frontier[current_chunk] = true;

    int left = 0;
    int right = 0; 
    int above = 0;
    int below = 0;

    for (int i = 0; i < chunks_amount * chunks_amount; i++) {
        left = 0; //Resetting the wall_variables - forgot to do this for a while! source of much pain.
        right = 0; 
        above = 0;
        below = 0;
        if (current_chunk % chunks_amount != 0 && completed_chunks[current_chunk - 1]) {//Hitting a completed chunk
            left = 2;
        } else if (current_chunk % chunks_amount == 0) {left = 1;} //Hitting a wall - need to notify image generator for black border
        if ((current_chunk + 1) % chunks_amount != 0 && completed_chunks[current_chunk + 1]) {
            right = 2;
        } else if ((current_chunk + 1) % chunks_amount == 0) {right = 1;}
        if (current_chunk >= chunks_amount && completed_chunks[current_chunk - chunks_amount]) {
            above = 2;
        } else if (current_chunk < chunks_amount) {above = 1;}
        if (current_chunk < chunks_amount * (chunks_amount - 1) && completed_chunks[current_chunk + chunks_amount]) {
            below = 2;
        } else if (current_chunk >= chunks_amount * (chunks_amount - 1)) {below = 1;}
        std::cout << "Maze_section: " << maze_chunk_name(current_chunk, chunks_amount, (chunk_size + image_output_length - 1) / image_output_length, 0) << "\n";
        maze(chunk_size, image_output_length, left, right, above, below, current_chunk, chunks_amount);

        completed_chunks[current_chunk] = true;

        //Left
        if (current_chunk - 1 >= 0 && current_chunk % chunks_amount != 0) { //Adding to the frontier //&& completed_chunks[current_chunk - 1] == false doesn't need to exist because chunk_frontier contains completed aswell
            if (!chunk_frontier[current_chunk - 1]) { //To prevent two of the same chunk choices.
                chunk_choices.push_back(current_chunk - 1);
                chunk_frontier[current_chunk - 1] = true;
            }
        }
        //Right
        if (current_chunk + 1 <= chunks_amount * chunks_amount && (current_chunk + 1) % chunks_amount != 0) {
            if (!chunk_frontier[current_chunk + 1]) {
                chunk_choices.push_back(current_chunk + 1);
                chunk_frontier[current_chunk + 1] = true;
            }
        }
        //Above
        if (current_chunk - chunks_amount >= 0) {
            if (!chunk_frontier[current_chunk - chunks_amount]) {
                chunk_choices.push_back(current_chunk - chunks_amount);
                chunk_frontier[current_chunk - chunks_amount] = true;
            }
        }
        //Below
        if (current_chunk + chunks_amount < chunks_amount * chunks_amount) {
            if (!chunk_frontier[current_chunk + chunks_amount]) {
                chunk_choices.push_back(current_chunk + chunks_amount);
                chunk_frontier[current_chunk + chunks_amount] = true;
            }
        }
        if (i < chunks_amount * chunks_amount - 1) { //We don't need to choose a new chunk at the end
            int index = rand() % chunk_choices.size(); //Choosing the new chunk.
            current_chunk = chunk_choices[index];
            std::swap(chunk_choices[index], chunk_choices.back());
            chunk_choices.pop_back();
        }
    }

    //Writing Batch file
    std::fstream batch;
    batch.open("maze_chunk_combiner.bat", std::ios::out);
    batch << "cd C:\\Users\\User\\Documents (Local)\\Maze Gen\\C++ Implementation\\Optimised c++\\Final maze generator\n";
    batch << "\"C:\\Users\\User\\Documents (Local)\\Maze Gen\\C++ Implementation\\Optimised c++\\vips-dev-8.17\\bin\\vips.exe\" arrayjoin \"";
    for (int y = 0; y < chunks_amount * ((chunk_size + image_output_length - 1) / image_output_length); y++) {
        for (int x = 0; x < chunks_amount; x++) {
            batch << "Maze_" << x << "_"; 
            for (int i = 0; i < 4 - std::to_string(y).length(); i ++) { //padding with 0s
                batch << "0";
            }
            batch << y << ".png ";
        }
    }
    batch << "\" Full_Maze.png --across=" << chunks_amount; //Don't need --halign=high --valign=high anymore because image borders are now expanded in maze().

    //Create a file order text file
    /*std::fstream file_order;
    file_order.open("fileorder.txt", std::ios::out);
    for (int y = 0; y < chunks_amount * ((chunk_size + image_output_length - 1) / image_output_length); y++) {
        for (int x = 0; x < chunks_amount; x++) {
            file_order << "Maze_" << x << "_"; 
            for (int i = 0; i < 4 - std::to_string(y).length(); i ++) { //padding with 0s
                file_order << "0";
            }
            file_order << y << ".png ";
        }
    }*/
}