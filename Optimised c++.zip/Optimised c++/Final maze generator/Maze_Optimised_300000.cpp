#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <array>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <random>
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h" //Drawing images

/*
cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++
g++ -Ofast -march=native -flto -std=c++20 -o Maze_program_300000 Maze_Optimised_300000.cpp

g++ -Ofast -march=native -flto -std=c++20 -IC:\Users\Benja\vcpkg\installed\x64-windows-static\include -LC:\Users\Benja\vcpkg\installed\x64-windows-static\lib Maze_Optimised_300000.cpp -o Maze_program_300000 -lOpenImageIO
-IC:\Users\Benja\vcpkg\installed\x64-windows-static\include
-LC:\Users\Benja\vcpkg\installed\x64-windows-static\lib -lOpenImageIO

//Remember for large sets of images (any that contain 2 digit numbers) the number must be padded with zeros - 000,001,002...010,011,012
cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\Generated\40,000x_Maze
C:\Users\Benja\OneDrive\Desktop\Utilities\ImageMagick-7.1.2-1-portable-Q8-x64\magick.exe -verbose -limit memory 16GiB -limit map 32GiB maze_*.png -monochrome maze_mono_%d.png
C:\Users\Benja\OneDrive\Desktop\Utilities\ImageMagick-7.1.2-1-portable-Q8-x64\magick.exe -verbose -limit memory 16GiB -limit map 32GiB maze_mono_*.png -append maze_full.png

cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++
C:\Users\Benja\OneDrive\Desktop\Utilities\ImageMagick-7.1.2-1-portable-Q8-x64\magick.exe -verbose -limit memory 16GiB -limit map 32GiB maze_0_*_0.png -append maze_full_%d.png

cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\Final maze generator\tiles
"C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\vips-dev-8.17\bin\vips.exe" arrayjoin Maze_*.png temp.v --across 10                Need to change maze numbering for this
"C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\vips-dev-8.17\bin\vips.exe" tiffsave temp.v Full_Maze.tif --bigtiff

"C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\vips-dev-8.17\bin\vips.exe" arrayjoin "Maze_0_0000.png Maze_1_0000.png Maze_2_0000.png" Maze_test.png --across 3
"C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\vips-dev-8.17\bin\vips.exe" arrayjoin "All_Mazes" Full_Maze.png --across 10




cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\Final maze generator\tiles
"C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++\vips-dev-8.17\bin\vips.exe" arrayjoin "Maze_0_0000.png Maze_1_0000.png Maze_2_0000.png" Full_Maze.png --across 10

*/

std::string maze_chunk_name (int chunk_pos, int chunks_amount, int sections, int num) {
    int chunk_x = chunk_pos % chunks_amount;
    int chunk_y = chunk_pos / chunks_amount * sections + num;
    std::string name = "Maze_";
    name += std::to_string(chunk_x);
    name += "_";
    for (int i = 0; i < 4 - std::to_string(chunk_y).length(); i ++) { //padding with 0s
        name += "0";
    }
    name += std::to_string(chunk_y);
    //name += std::to_string(chunk_pos*sections+num*chunks_amount+1);
    name += ".png";
    return name;
}

/*std::string maze_name(int num, std::string name) {
    name += "_";
    name += std::to_string(num);
    name += ".png";
    return name;
}*/

int maze(int size, int max_image_length, int left_wall, int right_wall, int above_wall, int below_wall, int current_chunk, int chunks_amount) {
    //int type = 0;
    int completed = 0;
    int choices[4] = { 0, 0, 0, 0 };
    int chosen = 0;
    int wall = 0;
    int choice_length = 0;
    std::vector<bool> horizontal_vec(size * (size - 1), true);
    std::vector<bool> vertical_vec(size * (size - 1), true);
    std::vector<unsigned int> VNC;
    VNC.reserve(size * size / 3); //This might be why higher loop numbers results in slower code - (size*size) instead maybe
    std::vector<int> VNC_map(size * size, -1); ////Maybe shouldn't be unsigned and set to a signed int
    std::vector<bool> visited(size * size, false);
    int percent = 0;

    static std::vector<bool> wall_data((size - 1) * 4 * chunks_amount * chunks_amount, true); //Alot of wasted space - wall on the edge of the full maze will never be filled and duplicate walls between chunks. System may be replaced

    std::random_device random_device;
    std::minstd_rand random_engine{random_device()};
    std::uniform_int_distribution dist_init{0, size * size - 1};

    unsigned int start_choices_len = 0; //The amount of cells at the front of the visited vector that are starting cells
    std::vector<bool> start_choices_map(size * size, false); //For checking if a starting cell has been chosen indirectly
    int current;

    if (left_wall < 2 && right_wall < 2 && above_wall < 2 && below_wall < 2) { //Must be the first maze chunk.
        current = dist_init(random_engine); //Using <random> instead because cstdint rand() has a limit for large numbers.
        visited[current] = true;
        VNC.push_back(current);
        VNC_map[current] = VNC.size() - 1;
    } else {
        if (left_wall == 2) { //Left wall logic
            for (int cell = 0; cell < size; cell ++) {
                if (visited[size * cell] == false) { //To prevent duplicating cells at the corners
                    visited[size * cell] = true;
                    VNC.push_back(size * cell);
                    VNC_map[size * cell] = VNC.size() - 1;

                    start_choices_len ++;
                    start_choices_map[size * cell] = true;
                }
            }
            for (int wall = 0; wall < size - 1; wall ++) {
                vertical_vec[wall * size] = wall_data[(current_chunk - 1) * (size - 1) * 4 + (size - 1) + wall];
            }
        }
        if (right_wall == 2) { //right wall logic
            for (int cell = 0; cell < size; cell ++) {
                if (visited[size - 1 + size * cell] == false) {
                    visited[size - 1 + size * cell] = true;
                    VNC.push_back(size - 1 + size * cell);
                    VNC_map[size - 1 + size * cell] = VNC.size() - 1;

                    start_choices_len ++;
                    start_choices_map[size - 1 + size * cell] = true;
                }
            }
            for (int wall = 0; wall < size - 1; wall ++) {
                vertical_vec[wall * size + size - 1] = wall_data[(current_chunk + 1) * (size - 1) * 4 + wall];
            }
        }
        if (above_wall == 2) { //above wall logic
            for (int cell = 0; cell < size; cell ++) {
                if (visited[cell] == false) {
                    visited[cell] = true;
                    VNC.push_back(cell);
                    VNC_map[cell] = VNC.size() - 1;

                    start_choices_len ++;
                    start_choices_map[cell] = true;
                }
            }
            for (int wall = 0; wall < size - 1; wall ++) {
                horizontal_vec[wall] = wall_data[(current_chunk - chunks_amount) * (size - 1) * 4 + 3 * (size - 1) + wall];
            }
        }
        if (below_wall == 2) { //below wall logic
            for (int cell = 0; cell < size; cell ++) {
                if (visited[size * (size - 1) + cell] == false) {
                    visited[size * (size - 1) + cell] = true;
                    VNC.push_back(size * (size - 1) + cell);
                    VNC_map[size * (size - 1) + cell] = VNC.size() - 1;

                    start_choices_len ++;
                    start_choices_map[size * (size - 1) + cell] = true;
                }
            }
            for (int wall = 0; wall < size - 1; wall ++) {
                horizontal_vec[(size - 1) * (size - 1) + wall] = wall_data[(current_chunk + chunks_amount) * (size - 1) * 4 + 2 * (size - 1) + wall];
            }
        }
        //Current choosing logic
        current = VNC[rand() % VNC.size()];
    }

    while (completed < size * size) {
        percent++;
        if (percent % (size * size / 100) == 0) {
            std::cout << int(completed / float(size * size) * 100) << " Percent completed" << "\n";
        }

        choice_length = 0;
        //Left
        if (current - 1 >= 0 && visited[current - 1] == false && current % size != 0) {
            choices[choice_length] = current - 1;
            choice_length ++;
        }
        //Right
        if (current + 1 <= size * size && visited[current + 1] == false && (current + 1) % size != 0) {
            choices[choice_length] = current + 1;
            choice_length ++;
        }
        //Above
        if (current - size >= 0 && visited[current - size] == false) {
            choices[choice_length] = current - size;
            choice_length ++;
        }
        //Below
        if (current + size < size * size && visited[current + size] == false) {
            choices[choice_length] = current + size;
            choice_length ++;
        }
        if (choice_length <= 1) { //Because if there is one path it will be taken later anyway.
            completed++;
            if (VNC_map[current] != -1) {
                std::swap(VNC[VNC_map[current]], VNC.back());
                std::swap(VNC_map[current], VNC_map[VNC[VNC_map[current]]]);
                VNC.pop_back();
                VNC_map[current] = -1;
            }
            if (start_choices_map[current] == true) { //A starting choice has been chosen indirectly
                start_choices_map[current] == false;
                start_choices_len --;
            }
            if (choice_length == 0) { goto skip; } // No choices available, exit the loop.
        }
        chosen = choices[rand() % choice_length]; //Randomly choose one of the choices.
        VNC.push_back(chosen);
        VNC_map[chosen] = VNC.size() - 1;
        visited[chosen] = true;
        //Left
        if (current - chosen == 1) {
            wall = chosen / size * (size - 1) + chosen % size;
            horizontal_vec[wall] = false;
        }
        //Right
        else if (chosen - current == 1) {
            wall = current / size * (size - 1) + current % size;
            horizontal_vec[wall] = false;
        }
        //Above 
        else if (current - chosen == size) {
            vertical_vec[chosen] = false;
        }
        //Below
        else {
            vertical_vec[current] = false;
        }
        current = chosen;
        skip:
        if (VNC.size() != 0) {
            /*if (type == 0) { //To ensure more connections between chunks //Optional
                current = VNC.back();
            } else {
                current = VNC[rand() % VNC.size()];
            }
            if (rand() % 50 == 1) {
                if (type == 1) {
                    type = 0;
                } else {
                    type = 1;
                }
            }*/

             if (start_choices_len > 0 && rand() % 10 == 1) {
                current = VNC[rand() % start_choices_len];
            } else {
                current = VNC.back();
            }

            //current = VNC[rand() % VNC.size()]; //RANDOM mode
            //current = VNC[0]; //FIRST mode
            //current = VNC.back(); //LAST mode
        }
    }

    //Wall data saving
    std::cout << "Program is saving wall data.\n";
    if (left_wall == 0) {
        for (int wall = 0; wall < size - 1; wall ++) {
            wall_data[current_chunk * (size - 1) * 4 + wall] = vertical_vec[wall * size];
        }
    }
    if (right_wall == 0) {
        for (int wall = 0; wall < size - 1; wall ++) {
            wall_data[current_chunk * (size - 1) * 4 + (size - 1) + wall] = vertical_vec[wall * size + size - 1];
        }
    }
    if (above_wall == 0) {
        for (int wall = 0; wall < size - 1; wall ++) {
            wall_data[current_chunk * (size - 1) * 4 + 2 * (size - 1) + wall] = horizontal_vec[wall];
        }
    }
    if (below_wall == 0) {
        for (int wall = 0; wall < size - 1; wall ++) {
            wall_data[current_chunk * (size - 1) * 4 + 3 * (size - 1) + wall] = horizontal_vec[(size - 1) * (size - 1) + wall];
        }
    }

    //Image saving
    /*for (int i = 0; i < horizontal_vec.size(); i++) {
        std::cout << horizontal_vec[i];
    }
    std::cout << "\n";
    for (int i = 0; i < vertical_vec.size(); i++) {
        std::cout << vertical_vec[i];
    }*/
    std::cout << "Program is generating images.\n";
    int horizontal = 0;
    int vertical = 0;
    int image_length = 0;
    int picture_num = 0;

    //if (max_image_length > size) {max_image_length = size;} //Clamp max_image_length - not neccesary

    int width = size * 2 + 1;
    int height = 0; //int height = max_image_length * 2 + 1; now = 0 for simplicity
    if (left_wall != 1) {width -= 1;} //Black border
    if (right_wall != 1) {width -= 2;} //Black border and not removing right side
    if (above_wall != 1) {height -= 1;} //Black border
    if (below_wall != 1) {height -= 2;} //Black border and not removing bottom side

    int og_x = 0; //Original x for resetting x
    int og_y = 0; //Original y for resetting y
    if (left_wall == 1) {og_x = 1;} //Add black border to the left
    if (above_wall == 1) {og_y = 1;} //Add black border above
    int x = og_x;
    int y = og_y;

    std::vector<uint8_t> image(width * (max_image_length * 2 + 1), 0); //Not set to width * height to maintain room for 1st out of > 1 image section outputs

    for (int a = 0; a < size - 1; a++) {
        for (int b = 0; b < size - 1; b++) { //Horizontal
            image[y*width+x] = 255; //Cell intersections
            x ++;
            if (horizontal_vec[horizontal] == false) {
                image[y*width+x] = 255; //Horizontal walls
            }
            horizontal++;
            x ++;
        }
        if (right_wall == 1) {image[y*width+x] = 255;} //Last cell intersection
        y ++;

        image_length ++;
        if (image_length >= max_image_length) {
            if (above_wall == 1 || picture_num != 0) { //If on first chunk, and is black border above, size is bigger for border. If not on first chunk, size is bigger to allow for vertical walls left from last picture.
                stbi_write_png(maze_chunk_name(current_chunk, chunks_amount, (size + max_image_length - 1) / max_image_length, picture_num).c_str(), width, max_image_length * 2, 1, image.data(), width);
            } else { //If on the first chunk and no black border above, size is one pixel smaller (size intersections, size - 1 vertical walls)
                stbi_write_png(maze_chunk_name(current_chunk, chunks_amount, (size + max_image_length - 1) / max_image_length, picture_num).c_str(), width, max_image_length * 2 - 1, 1, image.data(), width); //not width, height because otherwise the bottom cutoff will be taken out of all sections of image output 
            }
            image_length = 0;
            picture_num ++;
            std::fill(image.begin(), image.end(), 0);
            y = 0; //always set to 0 here - No black borders between chunks
            std::cout << "Image section " << picture_num << " generated\n";
        }

        x = og_x;
        for (int b = 0; b < size; b++) { //Vertical
            if (vertical_vec[vertical] == false) {
                if (b < size - 1 || right_wall == 1) {image[y*width+x] = 255;} //Removing right most vertical connections when supposed to
            }
            vertical++;
            x += 2;
        }
        x = og_x;
        y ++;
    }

    if (below_wall == 1) {
        for (int b = 0; b < size - 1; b++) { //Last non-white horizontal row
            image[y*width+x] = 255; //Cell intersections
            x ++;
            if (horizontal_vec[horizontal] == false) {
                image[y*width+x] = 255; //Horizontal walls
            }
            horizontal++;
            x ++;
        }
        if (right_wall == 1) {image[y*width+x] = 255;} //Last cell intersection
    }
    image_length ++;

    if (below_wall == 1) {
        stbi_write_png(maze_chunk_name(current_chunk, chunks_amount, (size + max_image_length - 1) / max_image_length, picture_num).c_str(), width, image_length * 2 + 1, 1, image.data(), width); // 1 extra pixel for bottom border
    } else {
        stbi_write_png(maze_chunk_name(current_chunk, chunks_amount, (size + max_image_length - 1) / max_image_length, picture_num).c_str(), width, image_length * 2 - 1, 1, image.data(), width); // 1 less pixel for row shaved off
    }
    if (max_image_length >= size) { //So it still works when not outputting image in pieces
        stbi_write_png(maze_chunk_name(current_chunk, chunks_amount, (size + max_image_length - 1) / max_image_length, picture_num).c_str(), width, image_length * 2 + 1 + height, 1, image.data(), width); //(image_length * 2 + 1) + (height - (max_image_length * 2 + 1))
    }
    //for (auto it = image.begin(); it != image.end(); it++){
        //std::cout << (static_cast<int>(*it) ? 1 : 0);
    //}
    std::cout << "All " << picture_num + 1 << " image sections generated\n";
    return 0;
}

int main() {
    int chunk_size = 30; //30,000 //In cells
    int image_output_length = 15; //15,000 //In cells
    int chunks_amount = 10; //10
    std::cout << "chunk_size\n";
    std::cin >> chunk_size;
    std::cout << "image_output_length\n";
    std::cin >> image_output_length;
    std::cout << "chunks_amount\n";
    std::cin >> chunks_amount;
    std::vector<bool> completed_chunks(chunks_amount * chunks_amount, false);
    std::vector<unsigned int> chunk_choices; //A list of all frontier chunks to generate next
    chunk_choices.reserve(chunks_amount * chunks_amount / 3);
    std::vector<bool> chunk_frontier(chunks_amount * chunks_amount, false); //Which chunks are frontier - for making sure frontier chunks aren't stored twice

    srand(time(NULL));
    std::random_device random_device;
    std::minstd_rand random_engine{random_device()};
    std::uniform_int_distribution dist_chunk{0, chunks_amount * chunks_amount - 1};
    int current_chunk = dist_chunk(random_engine);
    chunk_frontier[current_chunk] = true;

    int left = 0;
    int right = 0; 
    int above = 0;
    int below = 0;

    for (int i = 0; i < chunks_amount * chunks_amount; i++) {
        left = 0; //Resetting the wall_variables - forgot to do this for a while! source of much pain.
        right = 0; 
        above = 0;
        below = 0;
        if (current_chunk % chunks_amount != 0 && completed_chunks[current_chunk - 1]) {//Hitting a completed chunk
            left = 2;
        } else if (current_chunk % chunks_amount == 0) {left = 1;} //Hitting a wall - need to notify image generator for black border
        if ((current_chunk + 1) % chunks_amount != 0 && completed_chunks[current_chunk + 1]) {
            right = 2;
        } else if ((current_chunk + 1) % chunks_amount == 0) {right = 1;}
        if (current_chunk >= chunks_amount && completed_chunks[current_chunk - chunks_amount]) {
            above = 2;
        } else if (current_chunk < chunks_amount) {above = 1;}
        if (current_chunk < chunks_amount * (chunks_amount - 1) && completed_chunks[current_chunk + chunks_amount]) {
            below = 2;
        } else if (current_chunk >= chunks_amount * (chunks_amount - 1)) {below = 1;}
        std::cout << "Maze_section: " << maze_chunk_name(current_chunk, chunks_amount, (chunk_size + image_output_length - 1) / image_output_length, 0) << "\n";
        //maze(chunk_size, image_output_length, left, right, above, below, current_chunk, chunks_amount);

        completed_chunks[current_chunk] = true;

        //Left
        if (current_chunk - 1 >= 0 && current_chunk % chunks_amount != 0) { //Adding to the frontier //&& completed_chunks[current_chunk - 1] == false doesn't need to exist because chunk_frontier contains completed aswell
            if (!chunk_frontier[current_chunk - 1]) { //To prevent two of the same chunk choices.
                chunk_choices.push_back(current_chunk - 1);
                chunk_frontier[current_chunk - 1] = true;
            }
        }
        //Right
        if (current_chunk + 1 <= chunks_amount * chunks_amount && (current_chunk + 1) % chunks_amount != 0) {
            if (!chunk_frontier[current_chunk + 1]) {
                chunk_choices.push_back(current_chunk + 1);
                chunk_frontier[current_chunk + 1] = true;
            }
        }
        //Above
        if (current_chunk - chunks_amount >= 0) {
            if (!chunk_frontier[current_chunk - chunks_amount]) {
                chunk_choices.push_back(current_chunk - chunks_amount);
                chunk_frontier[current_chunk - chunks_amount] = true;
            }
        }
        //Below
        if (current_chunk + chunks_amount < chunks_amount * chunks_amount) {
            if (!chunk_frontier[current_chunk + chunks_amount]) {
                chunk_choices.push_back(current_chunk + chunks_amount);
                chunk_frontier[current_chunk + chunks_amount] = true;
            }
        }
        if (i < chunks_amount * chunks_amount - 1) { //We don't need to choose a new chunk at the end
            int index = rand() % chunk_choices.size(); //Choosing the new chunk.
            current_chunk = chunk_choices[index];
            std::swap(chunk_choices[index], chunk_choices.back());
            chunk_choices.pop_back();
        }
        //std::cout << current_chunk << "\n";
        //for (int i = 0; i < chunk_choices.size(); i++) {
        //    std::cout << chunk_choices[i] << " ";
        //}
        //std::cout << "\n";
        //for (int i = 0; i < chunk_frontier.size(); i++) {
        //    std::cout << (chunk_frontier[i] ? 1 : 0) << " ";
        //}
    }

    //Create batch file for image magick //Only works when the image isn't output in parts
    /*std::fstream batch;
    batch.open("maze_chunk_combiner.bat", std::ios::out);
    batch << "cd C:\\Users\\Benja\\Documents (Local)\\Maze Gen\\C++ Implementation\\Optimised c++\n";
    for (int chunk = 0; chunk < chunks_amount; chunk ++) {
        batch << "C:\\Users\\Benja\\OneDrive\\Desktop\\Utilities\\ImageMagick-7.1.2-1-portable-Q8-x64\\magick.exe -verbose -limit memory 16GiB -limit map 32GiB maze_" << chunk << "_*.png -append maze_full_" << chunk << ".tif\n";
    }
    batch << "C:\\Users\\Benja\\OneDrive\\Desktop\\Utilities\\ImageMagick-7.1.2-1-portable-Q8-x64\\magick.exe -verbose -limit memory 16GiB -limit map 32GiB maze_full_*.tif +append maze_full_complete.tif\n";*/

    std::fstream batch;
    batch.open("maze_chunk_combiner.bat", std::ios::out);
    batch << "cd C:\\Users\\Benja\\Documents (Local)\\Maze Gen\\C++ Implementation\\Optimised c++\\Generated\\Stitch_Test\n";
    std::vector<std::string> file_order_string_vector = {};
    std::string file_order_string = "";

    for (int chunk = 0; chunk < chunks_amount * ((chunk_size + image_output_length - 1) / image_output_length); chunk ++) {
        file_order_string_vector = {}; //Creating the file order string
        for (int file_num = 0; file_num < chunks_amount; file_num ++) {
            file_order_string = "";
            file_order_string += "Maze_";
            file_order_string += std::to_string(file_num);
            file_order_string += "_";
            for (int i = 0; i < 4 - std::to_string(chunk).length(); i ++) { //padding with 0s
                file_order_string += "0";
            }
            file_order_string += std::to_string(chunk);
            file_order_string_vector.push_back(file_order_string);
        }

        for (int pair = 0; pair < chunks_amount - 1; pair ++) {
            if (pair == 0) {batch << "\"C:\\Users\\Benja\\Documents (Local)\\Maze Gen\\C++ Implementation\\Optimised c++\\vips-dev-8.17\\bin\\vips.exe\" join " << file_order_string_vector[pair] << ".png " << file_order_string_vector[pair + 1] << ".png " << "temp_" << file_order_string_vector[pair + 1] << ".v horizontal\n";}
            else {
                batch << "\"C:\\Users\\Benja\\Documents (Local)\\Maze Gen\\C++ Implementation\\Optimised c++\\vips-dev-8.17\\bin\\vips.exe\" join temp_" << file_order_string_vector[pair] << ".v " << file_order_string_vector[pair + 1] << ".png temp_" << file_order_string_vector[pair + 1] << ".v horizontal\n";
                batch << "del /q temp_" << file_order_string_vector[pair] << ".v"; //Delete unused temp files
            }
        }
    }

    file_order_string_vector = {}; //Creating the file order string one last time
    for (int file_num = 0; file_num < chunks_amount * ((chunk_size + image_output_length - 1) / image_output_length); file_num ++) {
        file_order_string = "";
        file_order_string += "Maze_";
        file_order_string += std::to_string(chunks_amount - 1);
        file_order_string += "_";
        for (int i = 0; i < 4 - std::to_string(file_num).length(); i ++) { //padding with 0s
            file_order_string += "0";
        }
        file_order_string += std::to_string(file_num);
        file_order_string_vector.push_back(file_order_string);
    }
    for (int pair = 0; pair < chunks_amount * ((chunk_size + image_output_length - 1) / image_output_length) - 1; pair ++) {
        if (pair == 0) {
            batch << "\"C:\\Users\\Benja\\Documents (Local)\\Maze Gen\\C++ Implementation\\Optimised c++\\vips-dev-8.17\\bin\\vips.exe\" join temp_" << file_order_string_vector[pair] << ".v temp_" << file_order_string_vector[pair + 1] << ".v temp2_" << file_order_string_vector[pair + 1] << ".v vertical\n";
            batch << "del /q temp_" << file_order_string_vector[pair] << ".v"; //Delete first row unused temp file
        }
        else if (pair == chunks_amount * ((chunk_size + image_output_length - 1) / image_output_length) - 2) {batch << "\"C:\\Users\\Benja\\Documents (Local)\\Maze Gen\\C++ Implementation\\Optimised c++\\vips-dev-8.17\\bin\\vips.exe\" join temp2_" << file_order_string_vector[pair] << ".v temp_" << file_order_string_vector[pair + 1] << ".v Full_Maze.png vertical\n";} //Last image, special command
        else {
            batch << "\"C:\\Users\\Benja\\Documents (Local)\\Maze Gen\\C++ Implementation\\Optimised c++\\vips-dev-8.17\\bin\\vips.exe\" join temp2_" << file_order_string_vector[pair] << ".v temp_" << file_order_string_vector[pair + 1] << ".v temp2_" << file_order_string_vector[pair + 1] << ".v vertical\n";
            batch << "del /q temp2_" << file_order_string_vector[pair] << ".v"; //Delete unused temp files
        }
        batch << "del /q temp_" << file_order_string_vector[pair + 1] << ".v"; //Delete unused temp row files
    }

    //Create a file order text file
    std::fstream file_order;
    file_order.open("fileorder.txt", std::ios::out);
    for (int y = 0; y < chunks_amount * ((chunk_size + image_output_length - 1) / image_output_length); y++) {
        for (int x = 0; x < chunks_amount; x++) {
            file_order << "Maze_" << x << "_"; 
            for (int i = 0; i < 4 - std::to_string(y).length(); i ++) { //padding with 0s
                file_order << "0";
            }
            file_order << y << ".png ";
        }
    }
}