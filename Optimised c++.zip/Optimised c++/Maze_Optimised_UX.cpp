#include <iostream>
#include <fstream>
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h" //Drawing images
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h" //Loading images
#include <vector>
#include <unordered_map>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <random>

/*
cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++

g++ -Ofast -march=native -flto -std=c++20 -o Maze_program_UX Maze_Optimised_UX.cpp
*/

int main() {
    int x = 1;
    int y = 1;
    bool custom_contour = false;
    int hsize;
    int vsize;
    
    std::cout << "Please select maze width.\n";
    std::cin >> hsize;
    std::cout << "Please select maze height.\n";
    std::cin >> vsize;
    int type = 1;
    std::cout << "Please select mode:\nType \"1\" for RANDOM\nType \"2\" for FIRST\nType \"3\" for LAST\n";
    std::cin >> type;
    std::cout << "Would you like to continue for advanced customisation?\nY or N\n";
    std::string input;
    std::cin >> input;

    std::random_device random_device;
    std::minstd_rand random_engine{ random_device() };
    std::uniform_int_distribution dist_start{ 0, hsize * vsize - 1 };
    int current = dist_start(random_engine); //Using <random> instead because cstdint rand() has a limit for large numbers.

    if (input == "Y" || input == "y" || input == "yes" || input == "Yes") {
        std::cout << "Would you like to select a custom generation origin?\nY or N\n";
        std::cin >> input;
        if (input == "Y" || input == "y" || input == "yes" || input == "Yes") {
            std::cout << "Please select starting point X\nFrom 0 to " << hsize - 1 << "\n";
            int start_x;
            std::cin >> start_x;
            std::cout << "Please select starting point Y\nFrom 0 to " << vsize - 1 << "\n";
            int start_y;
            std::cin >> start_y;
            current = start_y * hsize + start_x;
        }
        else {
            std::cout << "Would you like to select a custom origin contour instead?\nY or N\n";
            std::cin >> input;
            if (input == "Y" || input == "y" || input == "yes" || input == "Yes") {
                std::cout << "1. The contour must be the same size as the maze.\n";
                std::cout << "2. The maze will \"grow\" from the white contours of the image provided. If white areas are not connected, parts of the maze will not be connected.\n";
                std::cout << "3. The contour is reccomended to connect dot to dot via the grid template. Remember to remove unused dots.";
                std::cout << "4. The file must be a png and be named \"contour.png\".\n";
                std::cout << "5. The file must be placed in the same folder as this executable.\n";
                std::cout << "Would you like to proceed with custom origin contour?\nY or N\nOr type T for a grid template.\n";
                std::cin >> input;
                if (input == "Y" || input == "y" || input == "yes" || input == "Yes") { custom_contour = true; }
                
                else if (input == "T" || input == "t" || input == "template" || input == "Template") {
                    std::vector<unsigned char> contour_template((hsize * 2 + 1) * (vsize * 2 + 1), 0);
                    x = 1;
                    y = 1;
                    for (int a = 0; a < vsize; a++) {
                        for (int b = 0; b < hsize - 1; b++) {
                            contour_template[(y * (hsize * 2 + 1) + x)] = 255;
                            x += 2;
                        }
                        contour_template[(y * (hsize * 2 + 1) + x)] = 255;
                        y += 2;
                        x = 1;
                    }
                    stbi_write_png("template.png", hsize * 2 + 1, vsize * 2 + 1, 1, contour_template.data(), (hsize * 2 + 1));
                    std::cout << "Would you like to proceed with custom origin contour?\nY or N\n";
                    std::cin >> input;
                    if (input == "Y" || input == "y" || input == "yes" || input == "Yes") { custom_contour = true; }
                }
            }
        }
    }

    /*
    For custom maze origins.
    For best results only remove white dots that do not touch the contour, even if the white dots aren't used.

    Best results creating custom shapes.
    When creating custom maze shapes, first get the shape of your choosing, black areas are filled, white areas are borders.
    Next, increase the contrast of the shape until it is monochrome. Then, combine the template image and shape with lighten blending.
    Flood fill the white outside of the shape to a non-white colour and flood fill the inside with white. Next flood flood fill the inside
    with black and flood fill the outside with white.
    The maze you will get from this will have a white background with black spots. Combine the maze and the original shape with lighten blending
    or (make sure to fill any holes in the maze that may occur due to an imperfect contour before this) flood fill the white background with black.
    Finally fill any holes in the maze. (If the shape wasn't fully monochrome before beggining this process, holes may occur.)
    */

    int completed = 0;
    int choices[4] = { 0, 0, 0, 0 };
    int chosen = 0;
    int wall = 0;
    int choicelength = 0;
    std::vector<bool> horizontal_vec(vsize * (hsize - 1), true);
    std::vector<bool> vertical_vec(hsize * (vsize - 1), true);
    std::vector<int> VNC;
    VNC.reserve(hsize * vsize / 3); //This might be why higher loop numbers results in slower code - (size*size) instead maybe
    std::vector<int> VNC_map(hsize * vsize, -1);
    std::vector<bool> visited(hsize * vsize, false);
    int percent = 0;
    srand(time(NULL));

    if (custom_contour == true) {
        int widthload, heightload, channels;
        unsigned char* contour = stbi_load("contour.png", &widthload, &heightload, &channels, 1);
        int horizontal = 0;
        int vertical = 0;
        int contour_current = 0;
        x = 1;
        y = 1;

        for (int a = 0; a < vsize; a++) { //Horizontal
            for (int b = 0; b < hsize - 1; b++) {
                if (contour[(y * (hsize * 2 + 1) + x)] >= 128) {
                    visited[contour_current] = true;
                    VNC.push_back(contour_current);
                    VNC_map[contour_current] = VNC.size() - 1;
                }
                contour_current += 1;
                x += 1;
                if (contour[(y * (hsize * 2 + 1) + x)] >= 128) {
                    horizontal_vec[horizontal] = false;
                }
                horizontal++;
                x += 1;
            }
            if (contour[(y * (hsize * 2 + 1) + x)] >= 128) {
                visited[contour_current] = true;
                VNC.push_back(contour_current);
                VNC_map[contour_current] = VNC.size() - 1;
            }
            contour_current += 1;
            y += 2;
            x = 1;
        }
        y = 2;
        x = 1;
        for (int a = 0; a < vsize - 1; a++) { //Vertical
            for (int b = 0; b < hsize; b++) {
                if (contour[(y * (hsize * 2 + 1) + x)] >= 128) {
                    vertical_vec[vertical] = false;
                }
                vertical++;
                x += 2;
            }
            y += 2;
            x = 1;
        }
        current = VNC[rand() % VNC.size()];
    }

    visited[current] = true;
    VNC.push_back(current);
    VNC_map[current] = VNC.size() - 1;

    while (completed < hsize * vsize) {
        int loop = 1;//(rand() % 1) + 1; //Need to investigate - at higher loop numbers, code runs slower.        1, 1;    3, 3;    3, 8;    3, 28;
        for (int i = 0; i < loop; i++) {
            if (completed >= hsize * vsize) { break; }
            percent++;
            if (percent % (hsize * vsize / 100) == 0) {
                std::cout << int(completed / float(hsize * vsize) * 100) << " Percent completed" << "\n";
            }

            choicelength = 0;
            //Left
            if (current - 1 >= 0 && visited[current - 1] == false && current % hsize != 0) {
                choices[choicelength] = current - 1;
                choicelength += 1;
            }
            //Right
            if (current + 1 <= hsize * vsize && visited[current + 1] == false && (current + 1) % hsize != 0) {
                choices[choicelength] = current + 1;
                choicelength += 1;
            }
            //Above
            if (current - hsize >= 0 && visited[current - hsize] == false && current - hsize < hsize * vsize && (current - hsize) > 0) {
                choices[choicelength] = current - hsize;
                choicelength += 1;
            }
            //Below
            if (current + hsize <= hsize * vsize && visited[current + hsize] == false && current + hsize < hsize * vsize && (current + hsize) > 0) {
                choices[choicelength] = current + hsize;
                choicelength += 1;
            }
            
            if (choicelength <= 1) { //Because if there is one path it will be taken later anyway.
                completed++;
                if (VNC_map[current] != -1) {
                    std::swap(VNC[VNC_map[current]], VNC.back());
                    std::swap(VNC_map[current], VNC_map[VNC[VNC_map[current]]]);
                    VNC.pop_back();
                    VNC_map[current] = -1;
                }
                if (choicelength == 0) { break; } // No choices available, exit the loop.
            }

            chosen = choices[rand() % choicelength]; //Randomly choose one of the choices.
            VNC.push_back(chosen);
            VNC_map[chosen] = VNC.size() - 1;
            visited[chosen] = true;

            //Left
            if (current - chosen == 1) {
                wall = chosen / hsize * (hsize - 1) + chosen % hsize;
                horizontal_vec[wall] = false;
            }
            //Right
            else if (chosen - current == 1) {
                wall = current / hsize * (hsize - 1) + current % hsize;
                horizontal_vec[wall] = false;
            }
            //Above 
            else if (current - chosen == hsize) {
                vertical_vec[chosen] = false;
            }
            //Below
            else {
                vertical_vec[current] = false;
            }
            current = chosen;
        }

        if (VNC.size() != 0) {
            if (type == 1) { int index = rand() % VNC.size(); current = VNC[index]; }
            else if (type == 2) { current = VNC[0]; }
            else if (type == 3) { current = VNC.back(); }
            else { return 1; }
        }
    }

    //Image saving
    std::cout << "Program will close when image is generated.\n";
    int horizontal = 0;
    int vertical = 0;
    x = 1;
    y = 1;
    std::vector<unsigned char> image((hsize * 2 + 1) * (vsize * 2 + 1), 0);

    for (int a = 0; a < vsize; a++) { //Horizontal
        for (int b = 0; b < hsize - 1; b++) {
            image[(y * (hsize * 2 + 1) + x)] = 255;
            x += 1;
            if (horizontal_vec[horizontal] == false) {
                image[(y * (hsize * 2 + 1) + x)] = 255;
            }
            horizontal++;
            x += 1;
        }
        image[(y * (hsize * 2 + 1) + x)] = 255;
        y += 2;
        x = 1;
    }
    y = 2;
    x = 1;
    for (int a = 0; a < vsize - 1; a++) { //Vertical
        for (int b = 0; b < hsize; b++) {
            if (vertical_vec[vertical] == false) {
                image[(y * (hsize * 2 + 1) + x)] = 255;
            }
            vertical++;
            x += 2;
        }
        y += 2;
        x = 1;
    }
    stbi_write_png("maze.png", hsize * 2 + 1, vsize * 2 + 1, 1, image.data(), (hsize * 2 + 1));

    return 0;
}