#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <random>
using namespace std;

/*
cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++

g++ -Ofast -march=native -flto -std=c++20 -o Maze_program_Optimised_2 Maze_Optimised.cpp
*/
 
int main() {
    int size = 20000;
    int completed = 0;
    int choices[4] = { 0, 0, 0, 0 };
    int chosen = 0;
    int wall = 0;
    int choicelength = 0;
    vector<bool> horizontal(size * (size - 1), true);
    vector<bool> vertical(size * (size - 1), true);
    vector<int> VNC;
    VNC.reserve(size * size / 3); //This might be why higher loop numbers results in slower code - (size*size) instead maybe
    vector<int> VNC_map(size * size, -1);
    vector<bool> visited(size * size, false);
    int percent = 0;

    srand(time(NULL));
    random_device random_device;
    minstd_rand random_engine{random_device()};
    uniform_int_distribution dist_init{0, size * size - 1};
    uniform_int_distribution dist_choice{0, 3};

    int current = dist_init(random_engine); //Using <random> instead because cstdint rand() has a limit for large numbers.
    cout << current << "\n";
    visited[current] = true;
    VNC.push_back(current);
    VNC_map[current] = VNC.size() - 1;


    while (completed < size * size) {
        int loop = 1; //(rand() % 1) + 1; //Need to investigate - at higher loop numbers, code runs slower.        1, 1;    3, 3;    3, 8;    3, 28;
        for (int i = 0; i < loop; i++) {
            if (completed >= size * size) { break; }
            percent++;
            if (percent % (size * size / 100) == 0) {
                cout << int(completed / float(size * size) * 100) << " Percent completed" << "\n";
            }

            choicelength = 0;
            //Left
            if (current - 1 >= 0 && visited[current - 1] == false && current % size != 0) {
                choices[choicelength] = current - 1;
                choicelength += 1;
            }
            //Right
            if (current + 1 <= size * size && visited[current + 1] == false && (current + 1) % size != 0) {
                choices[choicelength] = current + 1;
                choicelength += 1;
            }
            //Above
            if (current - size >= 0 && visited[current - size] == false && current - size < size * size && (current - size) > 0) {
                choices[choicelength] = current - size;
                choicelength += 1;
            }
            //Below
            if (current + size <= size * size && visited[current + size] == false && current + size < size * size && (current + size) > 0) {
                choices[choicelength] = current + size;
                choicelength += 1;
            }
            if (choicelength <= 1) { //Because if there is one path it will be taken later anyway.
                completed++;
                if (VNC_map[current] != -1) {
                    swap(VNC[VNC_map[current]], VNC.back());
                    swap(VNC_map[current], VNC_map[VNC[VNC_map[current]]]);
                    VNC.pop_back();
                    VNC_map[current] = -1;
                }
                if (choicelength == 0) { break; } // No choices available, exit the loop.
            }
            chosen = choices[rand() % choicelength]; //Randomly choose one of the choices.
            VNC.push_back(chosen);
            VNC_map[chosen] = VNC.size() - 1;
            visited[chosen] = true;
            //Left
            if (current - chosen == 1) {
                wall = chosen / size * (size - 1) + chosen % size;
                horizontal[wall] = false;
            }
            //Right
            else if (chosen - current == 1) {
                wall = current / size * (size - 1) + current % size;
                horizontal[wall] = false;
            }
            //Above 
            else if (current - chosen == size) {
                vertical[chosen] = false;
            }
            //Below
            else {
                vertical[current] = false;
            }
            current = chosen;
        }
        if (VNC.size() != 0) {
            int index = rand() % VNC.size(); //In python, this would be VNC.size()-1 but C++ does not include the max for rand.
            current = VNC[index]; //RANDOM mode
            //current = VNC[0]; //FIRST mode
            //current = VNC.back(); //LAST mode
        }
    }
    //.txt data saving.
    string htext = "";
    for (int h = 0; h < horizontal.size(); h++) {
        if (horizontal[h] == true) { htext.append("1"); }
        else { htext.append("0"); }
    }
    string vtext = "";
    for (int v = 0; v < vertical.size(); v++) {
        if (vertical[v] == true) { vtext.append("1"); }
        else { vtext.append("0"); }
    }
    fstream MazeTXT;
    MazeTXT.open("Maze.txt", ios::out);
    MazeTXT << htext;
    MazeTXT << vtext;
    MazeTXT.close();
    return 0;
}