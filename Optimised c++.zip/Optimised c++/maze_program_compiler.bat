cd C:\Users\Benja\Documents (Local)\Maze Gen\C++ Implementation\Optimised c++
g++ -Ofast -march=native -flto -std=c++20 -o Maze_program Maze_Optimised_300000.cpp